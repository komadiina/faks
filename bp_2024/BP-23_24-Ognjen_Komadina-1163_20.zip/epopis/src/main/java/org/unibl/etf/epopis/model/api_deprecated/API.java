package org.unibl.etf.epopis.model.api_deprecated;

import lombok.Getter;

@Getter
public class API {
    public String message;
}
