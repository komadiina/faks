package org.unibl.etf.epopis.app;

public class Main {
    public static void main(String[] a) {
    }
}
