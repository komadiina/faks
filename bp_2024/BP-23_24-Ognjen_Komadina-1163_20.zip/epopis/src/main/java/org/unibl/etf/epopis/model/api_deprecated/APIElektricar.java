package org.unibl.etf.epopis.model.api_deprecated;

public class APIElektricar extends API {
    public void popisi() {

    }

    public void napraviPredracun() {

    }

    public void posaljiPredracun() {

    }
}
