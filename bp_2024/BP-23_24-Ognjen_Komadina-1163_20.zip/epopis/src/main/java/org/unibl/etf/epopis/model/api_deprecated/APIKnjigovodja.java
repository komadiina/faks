package org.unibl.etf.epopis.model.api_deprecated;

public class APIKnjigovodja extends API {
    public void obradiPredracun() {

    }

    public void provjeriKasnjenja() {

    }

    public void posaljiDokument() {

    }
}
