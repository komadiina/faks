package org.unibl.etf.epopis.model.exceptions;

public class RegisterException extends Exception {
    public RegisterException(String message) { super(message); }
    public RegisterException() { super(); }
}
