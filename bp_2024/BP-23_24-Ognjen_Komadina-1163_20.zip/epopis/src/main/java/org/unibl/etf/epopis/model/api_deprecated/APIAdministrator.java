package org.unibl.etf.epopis.model.api_deprecated;

public class APIAdministrator extends API {
    public void dodajMjesto() {

    }

    public void iskljuciNalog() {

    }

    public void dodajSnabdjevaca() {

    }

    public void dodajDistributera() {

    }

    public void izbrisiSnabdjevaca() {

    }

    public void izbrisiDistributera() {

    }
}
